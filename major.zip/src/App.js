import React, { Component } from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Face from './components/facemesh/App.js'
import Hand from './components/Gesture/App.js'
import Speak from './components/speak/App.js'
//import Expression from './components/Face-Detection-JavaScript/index.html'
import './App.css'

class App extends Component {
  render() {
    return (
      <Router>
        {/* <div className="App"> */}
        <ul>
          <li>
            <Link to="/facemesh/App.js">Face</Link>
          </li>
          <li>
            <Link to="/speak/App.js">Speak</Link>
          </li>
          <li>
            <Link to="/Gesture/App.js">hand</Link>
          </li>
          <li>
            <a href="https://vidzaiexpressiondetection.netlify.app/">
              {/* <Link to="D:\HMI\Emotion-detection\Face-Detection-JavaScript\index.html"> */}{' '}
              {/* Face Expression
            </Link> */}
              Face Expression
            </a>
          </li>
        </ul>
        <Routes>
          <Route exact path="/facemesh/App.js" element={<Face />}></Route>
          <Route exact path="/speak/App.js" element={<Speak />}></Route>
          <Route exact path="/Gesture/App.js" element={<Hand />}></Route>
          {/* <Route element={<Expression />}></Route> */}
        </Routes>
        {/* </div> */}
        {/* <a href="https://superb-beijinho-8340d3.netlify.app/">
          Face Expression
        </a> */}
      </Router>
    )
  }
}

export default App
