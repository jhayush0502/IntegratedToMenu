import React from 'react'
import Webcam from 'react-webcam'
import SpeechRecognition, {
  useSpeechRecognition,
} from 'react-speech-recognition'

const App = () => {
  const { transcript, resetTranscript } = useSpeechRecognition({
    continuous: true,
  })
  console.log(transcript)

  if (!SpeechRecognition.browserSupportsSpeechRecognition()) {
    return null
  }

  return (
    <div style={{ paddingTop: '30vh' }}>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <p
          style={{
            // marginLeft: '20%',
            // marginRight: '20%',
            fontFamily: 'cursive',
            padding: '60px',
            paddingLeft: '5%',
            paddingRight: '5%',
            borderRadius: '20px',
            backgroundColor: 'darkseagreen',
            display: 'inline-block',
            justifyContent: 'center',
          }}
        >
          {transcript}
        </p>
      </div>
      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <button onClick={SpeechRecognition.startListening}>Start</button>
        <button onClick={SpeechRecognition.stopListening}>Stop</button>
        <button onClick={resetTranscript}>Reset</button>
      </div>
    </div>
  )
}
export default App
