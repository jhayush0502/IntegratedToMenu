import {
  Finger,
  FingerCurl,
  FingerDirection,
  GestureDescription,
} from 'fingerpose'

export const loveYouGesture = new GestureDescription('i_love_you')

// will figure out for different fingers->

//thumb
loveYouGesture.addCurl(Finger.Thumb, FingerCurl.NoCurl, 1.0)
loveYouGesture.addDirection(Finger.Thumb, FingerDirection.HorizontalLeft, 0.25)
loveYouGesture.addDirection(Finger.Thumb, FingerDirection.HorizontalRight, 0.25)

//index
loveYouGesture.addCurl(Finger.index, FingerCurl.NoCurl, 1.0)
loveYouGesture.addDirection(Finger.index, FingerDirection.VerticalUp, 0.25)

//Pinky
loveYouGesture.addCurl(Finger.Pinky, FingerCurl.NoCurl, 1.0)
loveYouGesture.addDirection(Finger.Pinky, FingerDirection.VerticalUp, 0.25)

//Middle
loveYouGesture.addCurl(Finger.Middle, FingerCurl.FullCurl, 0.75)
loveYouGesture.addDirection(Finger.Middle, FingerDirection.VerticalDown, 0.25)

//Ring
loveYouGesture.addCurl(Finger.Ring, FingerCurl.FullCurl, 0.75)
loveYouGesture.addDirection(Finger.Ring, FingerDirection.VerticalDown, 0.25)
