import {
  Finger,
  FingerCurl,
  FingerDirection,
  GestureDescription,
} from 'fingerpose'

export const Hello = new GestureDescription('hello')

// will figure out for different fingers->

//thumb
Hello.addCurl(Finger.Thumb, FingerCurl.NoCurl, 1.0)
Hello.addDirection(Finger.Thumb, FingerDirection.DiagonalUpLeft, 1.0)

//index
Hello.addCurl(Finger.index, FingerCurl.NoCurl, 1.0)
Hello.addDirection(Finger.index, FingerDirection.VerticalUp, 0.8)
Hello.addDirection(Finger.index, FingerDirection.DiagonalUpLeft, 0.5)

//Pinky
Hello.addCurl(Finger.Pinky, FingerCurl.NoCurl, 1.0)
Hello.addDirection(Finger.Pinky, FingerDirection.DiagonalUpRight, 0.85)
Hello.addDirection(Finger.Pinky, FingerDirection.VerticalUp, 0.5)

//Middle
Hello.addCurl(Finger.Middle, FingerCurl.NoCurl, 0.35)
Hello.addDirection(Finger.Middle, FingerDirection.VerticalUp, 1.0)

//Ring
Hello.addCurl(Finger.Ring, FingerCurl.NoCurl, 0.85)
Hello.addDirection(Finger.Ring, FingerDirection.VerticalUp, 0.95)
Hello.addDirection(Finger.Ring, FingerDirection.DiagonalUpRight, 0.15)
