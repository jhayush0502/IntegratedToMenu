import {
  Finger,
  FingerCurl,
  FingerDirection,
  GestureDescription,
} from 'fingerpose'

export const Smiling = new GestureDescription('smile')

// will figure out for different fingers->

//thumb
Smiling.addCurl(Finger.Thumb, FingerCurl.NoCurl, 1.0)
Smiling.addDirection(Finger.Thumb, FingerDirection.DiagonalUpLeft, 1.0)

//index
Smiling.addCurl(Finger.index, FingerCurl.NoCurl, 1.0)
Smiling.addDirection(Finger.index, FingerDirection.DiagonalUpRight, 1.0)

//Pinky
Smiling.addCurl(Finger.Pinky, FingerCurl.FullCurl, 1.0)
Smiling.addDirection(Finger.Pinky, FingerDirection.DiagonalDownLeft, 0.55)

//Middle
Smiling.addCurl(Finger.Middle, FingerCurl.FullCurl, 0.8)
Smiling.addDirection(Finger.Middle, FingerDirection.DiagonalDownLeft, 0.55)

//Ring
Smiling.addCurl(Finger.Ring, FingerCurl.FullCurl, 0.75)
Smiling.addDirection(Finger.Ring, FingerDirection.DiagonalDownLeft, 0.55)
