import {
  Finger,
  FingerCurl,
  FingerDirection,
  GestureDescription,
} from 'fingerpose'

export const Stopping = new GestureDescription('stop')

// will figure out for different fingers->

//thumb
Stopping.addCurl(Finger.Thumb, FingerCurl.NoCurl, 1.0)
Stopping.addDirection(Finger.Thumb, FingerDirection.VerticalUp, 1.0)

//index
Stopping.addCurl(Finger.index, FingerCurl.NoCurl, 1.0)
Stopping.addDirection(Finger.index, FingerDirection.VerticalUp, 1.0)

//Pinky
Stopping.addCurl(Finger.Pinky, FingerCurl.NoCurl, 1.0)
Stopping.addDirection(Finger.Pinky, FingerDirection.VerticalUp, 1.0)

//Middle
Stopping.addCurl(Finger.Middle, FingerCurl.NoCurl, 0.8)
Stopping.addDirection(Finger.Middle, FingerDirection.DiagonalDownLeft, 1.0)

//Ring
Stopping.addCurl(Finger.Ring, FingerCurl.NoCurl, 0.75)
Stopping.addDirection(Finger.Ring, FingerDirection.DiagonalDownLeft, 1.0)
