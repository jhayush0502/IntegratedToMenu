import {
  Finger,
  FingerCurl,
  FingerDirection,
  GestureDescription,
} from 'fingerpose'

export const Pointing = new GestureDescription('Points')

// will figure out for different fingers->

//thumb
Pointing.addCurl(Finger.Thumb, FingerCurl.FullCurl, 1.0)
Pointing.addDirection(Finger.Thumb, FingerDirection.HorizontalLeft, 0.25)
Pointing.addDirection(Finger.Thumb, FingerDirection.HorizontalRight, 0.25)
Pointing.addDirection(Finger.Thumb, FingerDirection.HorizontalUp, 0.25)
Pointing.addDirection(Finger.Thumb, FingerDirection.HorizontalDown, 0.25)

//index
Pointing.addCurl(Finger.index, FingerCurl.NoCurl, 1.0)
Pointing.addDirection(Finger.index, FingerDirection.VerticalUp, 0.25)

//Pinky
Pointing.addCurl(Finger.Pinky, FingerCurl.FullCurl, 1.0)
Pointing.addDirection(Finger.Pinky, FingerDirection.VerticalUp, 0.25)

//Middle
Pointing.addCurl(Finger.Middle, FingerCurl.FullCurl, 1.0)
Pointing.addDirection(Finger.Middle, FingerDirection.VerticalDown, 0.25)

//Ring
Pointing.addCurl(Finger.Ring, FingerCurl.FullCurl, 0.75)
Pointing.addDirection(Finger.Ring, FingerDirection.VerticalDown, 0.25)
